#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <iostream>
#include <cmath>
#include <stdio.h>
#include <unistd.h>
#include <ctime>
#include <list>
#include "tinyxml.h"
#include "circ.h"
#include "rec.h"
#include "aviao.h"
#include "bomba.h"
#define FPS 60
#define LAMBDA 111.11
#define LAMBDA2 6.66666667
#define LAMBDA3 1.5057
using namespace std;
 
//Key status
int keyStatus[256];

// Window dimensions
const GLint Width = 700;
const GLint Height = 700;

// Viewing dimensions
const GLint ViewingWidth = 500;
const GLint ViewingHeight = 500;
 
int animate = 0;

Robo *robo;

// ----------------------------------------------

int estado;
int botao;
// prototipos das funcoes
float delta;
float delta2;

//config do fundo
float largura;
float altura;

bool w = false;
bool a = false;
bool s = false;
bool d = false;

bool colisao = false;

long int inicial = time(NULL);
long int final, quadros = 0;
float vel;
bool fimDecolagem = false;

// titulo
//std::string titulo;
const char *titulo;

Circulo *circ;

Circulo *Arena;
Circulo *Aviao;
Bomba *bomba;
Retangulo *Pista;
Retangulo *Pista2;

float deslocamentox = 0;
float deslocamentoy = 0;

// 0 - Arena 1 - Aviao 2 - Inimigo Aereo 3 - Inimigo terrestre

std::list<Circulo *> inimigos;
std::list<Bomba *> bombas;

bool startGame = false;
bool primeiroDesenho = false;
float tamPista;
float distLimite;
float raioVoador;
float distAux;
float RaioAux;
const char *nome;
const char *tipo;
const char *caminho;
float velocidade;
float velocidadeIdeal;
float aceleracaoIdeal;
float deltax, deltay;
float deltax2, deltay2;
float raioOriginal;
float xOriginal, yOriginal;
float pistax1Original, pistax2Original, pistay1Original, pistay2Original;
float deltaxOriginal, deltayOriginal;
float thetaOriginal;
bool jaPassou = false;
bool curvando;

float curva;
float fator=0;
int z=0;

float theta = 0;
float tangente=0;
float scale = 0;
float thetaCanhao=0;
int m=0;
float thetaHelice = 0;
bool aApertado = false;
bool dApertado = false;
float velTiro;

float alberto, jadir;

void desenhaPista() {

  //glColor3f(0, 0, 0);
  //glBegin(GL_LINES);
    //  glVertex2f(Pista->getx1(), Pista->gety1());
     // glVertex2f(Pista->getx2(), Pista->gety2());
  //glEnd();

  glColor3f(0, 0, 0);
  glBegin(GL_LINES);
      glVertex2f(Pista2->getx1(), Pista2->gety1());
      glVertex2f(Pista2->getx2(), Pista2->gety2());
  glEnd();

}
bool ajuste = false;
 float aux;

/*
void desenhaBombas() {

  float distancia;
  for (std::list<Bomba *>::iterator it = bombas.begin(); it != bombas.end(); it++) {

  distancia = sqrt(pow((*it)->getxInicial() - (*it)->getx(), 2) + pow((*it)->getyInicial() - (*it)->gety(), 2));
  if(distancia < 240*vel) {

    float angulo;
    //int num_linhas;
    glColor3f((*it)->getR(), (*it)->getG(), (*it)->getB());
    glBegin(GL_POLYGON);
    for (int i = 0; i < 1000; i++)
    {
    angulo = i * 2 * M_PI / 1000;
    glVertex2f((*it)->getx() + (cos(angulo) * (*it)->getRaio()), (*it)->gety() + (sin(angulo) * (*it)->getRaio()));
    }
    glEnd();

   
    aux = (*it)->raioOriginal/2;
    (*it)->setRaio((*it)->getRaio() - aux/240);


    if((*it)->deltax > 0 && (*it)->deltay == 0) { // Pista reta horizontalmente

          if((*it)->getpx2() - (*it)->getpx1() > 0)
            (*it)->setx((*it)->getx() + (*it)->vel);
          if((*it)->getpx2() - (*it)->getpx1() < 0)
            (*it)->setx((*it)->getx() - (*it)->vel);
    }
    if((*it)->deltay > 0 && (*it)->deltax == 0) { // Pista reta verticalmente
          if((*it)->getpy2() - (*it)->getpy1() > 0)
            (*it)->sety((*it)->gety() + (*it)->vel);
          if((*it)->getpy2() - (*it)->getpy1() < 0)
            (*it)->sety((*it)->gety() - (*it)->vel);                 
    }

    if((*it)->deltax > 0 && (*it)->deltay > 0) { // Pista inclinada


          if((*it)->deltax > (*it)->deltay) {

            if(!(*it)->getajuste()) {
            if((*it)->getpx2() - (*it)->getpx1() > 0)
              (*it)->setx((*it)->getx() + Aviao->getRaio()*1.2);
            if((*it)->getpx2() - (*it)->getpx1() < 0)
              (*it)->setx((*it)->getx() - Aviao->getRaio()*1.2);
            if((*it)->getpy2() - (*it)->getpy1() > 0) 
               (*it)->sety((*it)->gety() + (Aviao->getRaio()*1.2)/((*it)->deltax/(*it)->deltay));
            if((*it)->getpy2() - (*it)->getpy1() < 0) 
              (*it)->sety((*it)->gety() - (Aviao->getRaio()*1.2)/((*it)->deltax/(*it)->deltay));
              (*it)->setajuste();
            }
            if((*it)->getpx2() - (*it)->getpx1() > 0)
              (*it)->setx((*it)->getx() + 2*vel);
            if((*it)->getpx2() - (*it)->getpx1() < 0)
              (*it)->setx((*it)->getx() - 2*vel);
            if((*it)->getpy2() - (*it)->getpy1() > 0) 
               (*it)->sety((*it)->gety() + (2*vel + (*it)->vel)/((*it)->deltax/(*it)->deltay));
            if((*it)->getpy2() - (*it)->getpy1() < 0) 
              (*it)->sety((*it)->gety() - (2*vel - (*it)->vel)/((*it)->deltax/(*it)->deltay));
          }
          if((*it)->deltay > (*it)->deltax) {
 
            if((*it)->getpy2() - (*it)->getpy1() > 0)
              (*it)->sety((*it)->gety() + (*it)->vel);
            if((*it)->getpy2() - (*it)->getpy1() < 0)
              (*it)->sety((*it)->gety() - (*it)->vel);
            if((*it)->getpx2() - (*it)->getpx1() > 0) 
               (*it)->setx((*it)->getx() + (*it)->vel/((*it)->deltay/(*it)->deltax));
            if((*it)->getpx2() - (*it)->getpx1() < 0) 
              (*it)->setx((*it)->getx() - (*it)->vel/((*it)->deltay/(*it)->deltax));
          }
          if((*it)->deltay == (*it)->deltax) {

            if((*it)->getpx2() - (*it)->getpx1() > 0)
              (*it)->setx((*it)->getx() + (*it)->vel);
            if((*it)->getpx2() - (*it)->getpx1() < 0)
              (*it)->setx((*it)->getx() - (*it)->vel);
            if((*it)->getpy2() - (*it)->getpy1() > 0)
              (*it)->sety((*it)->gety() + (*it)->vel);
            if((*it)->getpy2() - (*it)->getpy1() < 0)
              (*it)->sety((*it)->gety() - (*it)->vel);
          }
          
    }


  } else {
      bombas.erase(it++);
      //printf("bomba explodiu\n");
  }
      

 }

}
*/

void desenhaBombas() {

  float distancia;
  for (std::list<Bomba *>::iterator it = bombas.begin(); it != bombas.end(); it++) {

  if((*it)->tipo == 0) { //BOMBA

  distancia = sqrt(pow((*it)->getxInicial() - (*it)->getx(), 2) + pow((*it)->getyInicial() - (*it)->gety(), 2));
  if(distancia < 240*(*it)->getVel()) {

    float angulo;
    //int num_linhas;
    glColor3f((*it)->getR(), (*it)->getG(), (*it)->getB());
    glBegin(GL_POLYGON);
    for (int i = 0; i < 1000; i++)
    {
    angulo = i * 2 * M_PI / 1000;
    glVertex2f((*it)->getx() + (cos(angulo) * (*it)->getRaio()), (*it)->gety() + (sin(angulo) * (*it)->getRaio()));
    }
    glEnd();

   
    aux = (*it)->raioOriginal/2;
    (*it)->setRaio((*it)->getRaio() - aux/240);


    if((*it)->deltax > 0 && (*it)->deltay == 0) { // Pista reta horizontalmente

          if((*it)->getpx2() - (*it)->getpx1() > 0)
            (*it)->setx((*it)->getx() + (*it)->vel);
          if((*it)->getpx2() - (*it)->getpx1() < 0)
            (*it)->setx((*it)->getx() - (*it)->vel);
    }
    if((*it)->deltay > 0 && (*it)->deltax == 0) { // Pista reta verticalmente
          if((*it)->getpy2() - (*it)->getpy1() > 0)
            (*it)->sety((*it)->gety() + (*it)->vel);
          if((*it)->getpy2() - (*it)->getpy1() < 0)
            (*it)->sety((*it)->gety() - (*it)->vel);                 
    }

    if((*it)->deltax > 0 && (*it)->deltay > 0) { // Pista inclinada

          if((*it)->deltax > (*it)->deltay) {
            if((*it)->getpx2() - (*it)->getpx1() > 0)
              (*it)->setx((*it)->getx() + (*it)->vel);
            if((*it)->getpx2() - (*it)->getpx1() < 0)
              (*it)->setx((*it)->getx() - (*it)->vel);
            if((*it)->getpy2() - (*it)->getpy1() > 0) 
               (*it)->sety((*it)->gety() + (*it)->vel/((*it)->deltax/(*it)->deltay));
            if((*it)->getpy2() - (*it)->getpy1() < 0) 
              (*it)->sety((*it)->gety() - (*it)->vel/((*it)->deltax/(*it)->deltay));
          }
          if((*it)->deltay > (*it)->deltax) {
 
            if((*it)->getpy2() - (*it)->getpy1() > 0)
              (*it)->sety((*it)->gety() + (*it)->vel);
            if((*it)->getpy2() - (*it)->getpy1() < 0)
              (*it)->sety((*it)->gety() - (*it)->vel);
            if((*it)->getpx2() - (*it)->getpx1() > 0) 
               (*it)->setx((*it)->getx() + (*it)->vel/((*it)->deltay/(*it)->deltax));
            if((*it)->getpx2() - (*it)->getpx1() < 0) 
              (*it)->setx((*it)->getx() - (*it)->vel/((*it)->deltay/(*it)->deltax));
          }
          if((*it)->deltay == (*it)->deltax) {

            if((*it)->getpx2() - (*it)->getpx1() > 0)
              (*it)->setx((*it)->getx() + (*it)->vel);
            if((*it)->getpx2() - (*it)->getpx1() < 0)
              (*it)->setx((*it)->getx() - (*it)->vel);
            if((*it)->getpy2() - (*it)->getpy1() > 0)
              (*it)->sety((*it)->gety() + (*it)->vel);
            if((*it)->getpy2() - (*it)->getpy1() < 0)
              (*it)->sety((*it)->gety() - (*it)->vel);
          }
          
    }


  } else {
      bombas.erase(it++);
      //printf("bomba explodiu\n");
  }
      
  } else if((*it)->tipo == 1) { // TIRO

    distancia = sqrt(pow((*it)->getxInicial() - (*it)->getx(), 2) + pow((*it)->getyInicial() - (*it)->gety(), 2));
    if(distancia < 2*Arena->getRaio()) {

    float angulo;
    //int num_linhas;
    glColor3f((*it)->getR(), (*it)->getG(), (*it)->getB());
    glBegin(GL_POLYGON);
    for (int i = 0; i < 1000; i++)
    {
    angulo = i * 2 * M_PI / 1000;
    glVertex2f((*it)->getx() + (cos(angulo) * (*it)->getRaio()), (*it)->gety() + (sin(angulo) * (*it)->getRaio()));
    }
    glEnd();

    if((*it)->deltax > 0 && (*it)->deltay == 0) { // Pista reta horizontalmente

            if(!(*it)->getajuste()) {
            if((*it)->getpx2() - (*it)->getpx1() > 0)
              (*it)->setx((*it)->getx() + Aviao->getRaio()*1.2);
            if((*it)->getpx2() - (*it)->getpx1() < 0)
              (*it)->setx((*it)->getx() - Aviao->getRaio()*1.2);
              (*it)->setajuste();
            }

          if((*it)->getpx2() - (*it)->getpx1() > 0)
            (*it)->setx((*it)->getx() + velTiro*(*it)->vel);
          if((*it)->getpx2() - (*it)->getpx1() < 0)
            (*it)->setx((*it)->getx() - velTiro*(*it)->vel);
    }
    if((*it)->deltay > 0 && (*it)->deltax == 0) { // Pista reta verticalmente

            if(!(*it)->getajuste()) {
            if((*it)->getpy2() - (*it)->getpy1() > 0) 
               (*it)->sety((*it)->gety() + Aviao->getRaio()*1.2);
            if((*it)->getpy2() - (*it)->getpy1() < 0) 
              (*it)->sety((*it)->gety() - Aviao->getRaio()*1.2);
              (*it)->setajuste();
            }

          if((*it)->getpy2() - (*it)->getpy1() > 0)
            (*it)->sety((*it)->gety() + velTiro*(*it)->vel);
          if((*it)->getpy2() - (*it)->getpy1() < 0)
            (*it)->sety((*it)->gety() - velTiro*(*it)->vel);                 
    }

    if((*it)->deltax > 0 && (*it)->deltay > 0) { // Pista inclinada


          if((*it)->deltax > (*it)->deltay) {

            if(!(*it)->getajuste()) {
            if((*it)->getpx2() - (*it)->getpx1() > 0)
              (*it)->setx((*it)->getx() + Aviao->getRaio()*1.2);
            if((*it)->getpx2() - (*it)->getpx1() < 0)
              (*it)->setx((*it)->getx() - Aviao->getRaio()*1.2);
            if((*it)->getpy2() - (*it)->getpy1() > 0) 
               (*it)->sety((*it)->gety() + (Aviao->getRaio()*1.2)/((*it)->deltax/(*it)->deltay));
            if((*it)->getpy2() - (*it)->getpy1() < 0) 
              (*it)->sety((*it)->gety() - (Aviao->getRaio()*1.2)/((*it)->deltax/(*it)->deltay));
              (*it)->setajuste();
            }
            if((*it)->getpx2() - (*it)->getpx1() > 0)
              (*it)->setx((*it)->getx() + velTiro*vel);
            if((*it)->getpx2() - (*it)->getpx1() < 0)
              (*it)->setx((*it)->getx() - velTiro*vel);
            if((*it)->getpy2() - (*it)->getpy1() > 0) 
               (*it)->sety((*it)->gety() + velTiro* ((*it)->vel/((*it)->deltax/(*it)->deltay)));
            if((*it)->getpy2() - (*it)->getpy1() < 0) 
              (*it)->sety((*it)->gety() - velTiro* ((*it)->vel/((*it)->deltax/(*it)->deltay)));
          }
          if((*it)->deltay > (*it)->deltax) {

            
            if(!(*it)->getajuste()) {
            if((*it)->getpy2() - (*it)->getpy1() > 0)
              (*it)->sety((*it)->gety() + Aviao->getRaio()*1.2);
            if((*it)->getpy2() - (*it)->getpy1() < 0)
              (*it)->sety((*it)->gety() - Aviao->getRaio()*1.2);
            if((*it)->getpx2() - (*it)->getpx1() > 0) 
               (*it)->setx((*it)->getx() + (Aviao->getRaio()*1.2)/((*it)->deltay/(*it)->deltax));
            if((*it)->getpx2() - (*it)->getpx1() < 0) 
              (*it)->setx((*it)->getx() - (Aviao->getRaio()*1.2)/((*it)->deltay/(*it)->deltax));
              (*it)->setajuste();
            }
 
            if((*it)->getpy2() - (*it)->getpy1() > 0)
              (*it)->sety((*it)->gety() + velTiro*(*it)->vel);
            if((*it)->getpy2() - (*it)->getpy1() < 0)
              (*it)->sety((*it)->gety() - velTiro*(*it)->vel);
            if((*it)->getpx2() - (*it)->getpx1() > 0) 
               (*it)->setx((*it)->getx() + velTiro*((*it)->vel/((*it)->deltay/(*it)->deltax)));
            if((*it)->getpx2() - (*it)->getpx1() < 0) 
               (*it)->setx((*it)->getx() - velTiro*((*it)->vel/((*it)->deltay/(*it)->deltax)));
          }
          if((*it)->deltay == (*it)->deltax) {

            if(!(*it)->getajuste()) {
            if((*it)->getpx2() - (*it)->getpx1() > 0)
              (*it)->setx((*it)->getx() + Aviao->getRaio()*1.2);
            if((*it)->getpx2() - (*it)->getpx1() < 0)
              (*it)->setx((*it)->getx() - Aviao->getRaio()*1.2);
            if((*it)->getpy2() - (*it)->getpy1() > 0)
              (*it)->sety((*it)->gety() + Aviao->getRaio()*1.2);
            if((*it)->getpy2() - (*it)->getpy1() < 0)
              (*it)->sety((*it)->gety() - Aviao->getRaio()*1.2);
              (*it)->setajuste();
            }

            if((*it)->getpx2() - (*it)->getpx1() > 0)
              (*it)->setx((*it)->getx() + velTiro*(*it)->vel);
            if((*it)->getpx2() - (*it)->getpx1() < 0)
              (*it)->setx((*it)->getx() - velTiro*(*it)->vel);
            if((*it)->getpy2() - (*it)->getpy1() > 0)
              (*it)->sety((*it)->gety() + velTiro*(*it)->vel);
            if((*it)->getpy2() - (*it)->getpy1() < 0)
              (*it)->sety((*it)->gety() - velTiro*(*it)->vel);
          }
          
    }


  } else {
      bombas.erase(it++);
      //printf("bomba explodiu\n");
  }




  }

 }

}

void desenhaAviao() {

  float angulo;
  //int num_linhas;
  glColor3f(Aviao->getR(), Aviao->getG(), Aviao->getB());
  glBegin(GL_POLYGON);
  for (int i = 0; i < 1000; i++)
  {
    angulo = i * 2 * M_PI / 1000;
    glVertex2f(Aviao->getx() + (cos(angulo) * Aviao->getRaio()), Aviao->gety() + (sin(angulo) * Aviao->getRaio()));
  }
  glEnd();

}

void desenhaInimigos()
{

  for (std::list<Circulo *>::iterator it = inimigos.begin(); it != inimigos.end(); it++)
  {

    float angulo;
    //int num_linhas;
    glColor3f((*it)->getR(), (*it)->getG(), (*it)->getB());
    glBegin(GL_POLYGON);
    for (int i = 0; i < 1000; i++)
    {
      angulo = i * 2 * M_PI / 1000;
      glVertex2f((*it)->getx() + (cos(angulo) * (*it)->getRaio()), (*it)->gety() + (sin(angulo) * (*it)->getRaio()));
    }

    glEnd();
  }
  //glutPostRedisplay();
}
float ang;
void desenhaTeste() {

      //if(keyStatus[(int)('d')] ) {
                  //Aviao->sety(Aviao->gety() + curva);
  float angulo;
             glColor3f(1, 1, 1);
            glBegin(GL_POLYGON);
        for (int i = 0; i < 1000; i++)
        {
          angulo = i * 2 * M_PI / 1000;
          glVertex2f(Aviao->getx() + (cos(angulo) * 2*Aviao->getRaio()), Aviao->gety() + (sin(angulo) * 2*Aviao->getRaio()));
        }
        glEnd();
      //}          //theta= 0;
//

}

void ClicarMouse(int button, int state, int x, int y) 
{ 
    if(button==GLUT_LEFT_BUTTON && state==GLUT_DOWN)
    {
        //thetaCanhao = m;
       // m++;
      float xc, yc, deltx, delty, fator;
      xc = Pista->getx2() - Pista->getx1();
      yc = xc + 5*thetaHelice;//* tan(thetaHelice*M_PI/180);
      //printf("%f\n", tan(-30*M_PI/180));
      deltx = abs(xc - Pista->getx1());
      delty = abs(yc - Pista->gety1());

      if(thetaHelice > 0)
            fator = (thetaHelice*3.3)/45;
      if(thetaHelice < 0)
            fator = (thetaHelice*-14)/-45;
      if(thetaHelice == 0)
            fator = 0;


      if(fimDecolagem) {
      //printf("theta:%f y1:%f x2:%f y2:%f xc:%f yc:%f theta:%f delx:%f dely:%f\n", thetaHelice, Pista->gety1(), Pista->getx2(),Pista->gety2(), xc, yc, thetaHelice, deltx, delty);
      bomba = new Bomba(vel, Aviao->getRaio()/12, Aviao->getx(), Aviao->gety(), 1,1,1, deltax, deltay, Pista->getx1(), Pista->getx2(), Pista->gety1(), Pista->gety2(), 1);
      bombas.push_front(bomba);
      }

    } 
    if(button==GLUT_RIGHT_BUTTON && state==GLUT_UP)
    {
        //momento que se solta 
        //thetaCanhao = m;
        //m--; 
      
    }
    if(button==GLUT_RIGHT_BUTTON && state==GLUT_DOWN){
     
        if(fimDecolagem) {
        bomba = new Bomba(vel, Aviao->getRaio(), Aviao->getx(), Aviao->gety(), 0,0,0, deltax, deltay, Pista->getx1(), Pista->getx2(), Pista->gety1(), Pista->gety2(), 0);
        bombas.push_front(bomba);
        //printf("bomba!\n");
        }

    }
}

float xant, count = 0;
bool first = false;
void MouseAndandoNaoPressionado (int x, int y)
{
    //printf("Mouse ANDANDO solto na janela. Posição: (%d, %d)\n", x,y);
    float valor;
    valor = xant - x;
    //printf("%f\n", valor);
    valor = - valor;
    if(valor > 45)
        thetaHelice = 45;
    if(valor <-45)
        thetaHelice= -45;
    if(valor > 0 && valor < 45) {
        if(valor + thetaHelice > 45)
          thetaHelice = 45;
        else if(valor + thetaHelice < 45)
          thetaHelice += valor;
    }
    if(valor < 0 && valor > -45) {
        if(valor + thetaHelice < -45)
          thetaHelice = -45;
        else if(valor + thetaHelice > -45)
          thetaHelice +=valor;

    }                 
    xant = x;
}

int tecla =0;
void display(void)
{
    //cout << "entrou\n";
     // Clear the screen.
  
     glClear(GL_COLOR_BUFFER_BIT);
 
     
     
     float angulo;
  //int num_linhas;
    glColor3f(Arena->getR(), Arena->getG(), Arena->getB());
    glBegin(GL_POLYGON);
        for (int i = 0; i < 1000; i++)
        {
            angulo = i * 2 * M_PI / 1000;
            glVertex2f(largura + (cos(angulo) * Arena->getRaio()), largura + (sin(angulo) * Arena->getRaio()));
        }
        glEnd();


    desenhaPista();

    desenhaInimigos();

    desenhaBombas();

    //desenhaTeste();

    //desenhaAviao();

    //theta = tangente*180/M_PI;
        
    robo->DesenhaRobo(Aviao->getx(), Aviao->gety(), theta, scale,thetaCanhao,thetaHelice, Aviao->getRaio(), Aviao->getR(), Aviao->getG(), Aviao->getB());

    
     glutSwapBuffers(); 
}


float k;
void keyPress(unsigned char key, int x, int y)
{
    switch (key) {
    
        case 'a':
        case 'A':
             keyStatus[(int)('a')] = 1; //Using keyStatus trick
             curvando = true;
             break;
        case 'd':
        case 'D':
             keyStatus[(int)('d')] = 1; //Using keyStatus trick
             curvando = true;
             break;
        case 'u':
        case 'U':
             robo->RodaBraco1(-1);   //Without keyStatus trick
             startGame = true;
             break;
        case 'r':
        case 'R':
             startGame = false;
             Aviao->setx(xOriginal);
             Aviao->sety(yOriginal);   //Without keyStatus trick
             fimDecolagem = false;
             vel = aceleracaoIdeal;
             Aviao->setRaio(raioOriginal);
             scale = raioOriginal/LAMBDA2;
             jaPassou = false;
             Pista->setx1(pistax1Original);
             Pista->sety1(pistay1Original);
             Pista->setx2(pistax2Original);
             Pista->sety2(pistay2Original);
             deltax = abs(deltaxOriginal);
             deltay = abs(deltayOriginal);
             deltax2 = deltaxOriginal;
             deltay2 = deltayOriginal;
             theta = thetaOriginal;
             z=0;
             bombas.clear();
             // retirar todas as bombas da lista de bombas
             break;
        case '+':
             vel = vel +0.5;  //Without keyStatus trick
             break;
        case '-':
             k = vel - 0.5;
             if(k < 0)
                vel = 0;
             else
                vel = vel - 0.5;   //Without keyStatus trick
             break;
        case 27 :
             exit(0);
    }
    glutPostRedisplay();
}

void keyup(unsigned char key, int x, int y)
{
    keyStatus[(int)(key)] = 0;
    curvando = false; 
    if(tecla == 'd')
        tecla = 1;
    if(tecla == 'a')
        tecla = 2;
    glutPostRedisplay();
}

void ResetKeyStatus()
{
    int i;
    //Initialize keyStatus
    for(i = 0; i < 256; i++)
       keyStatus[i] = 0; 
}

void init(void)
{
    ResetKeyStatus();
    // The color the windows will redraw. Its done to erase the previous frame.
    /*
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Black, no opacity(alpha).
 
    glMatrixMode(GL_PROJECTION); // Select the projection matrix    
    glOrtho(-(ViewingWidth/2),     // X coordinate of left edge             
            (ViewingWidth/2),     // X coordinate of right edge            
            -(ViewingHeight/2),     // Y coordinate of bottom edge             
            (ViewingHeight/2),     // Y coordinate of top edge             
            -100,     // Z coordinate of the “near” plane            
            100);    // Z coordinate of the “far” plane
    glMatrixMode(GL_MODELVIEW); // Select the projection matrix    
    glLoadIdentity();
    */
     //glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glMatrixMode(GL_PROJECTION);
  //glLoadIdentity(); // cor de fundo
  //gluOrtho2D(0.0, 2*largura, 2*altura, 0.0);
  //glOrtho(0.0,1.0,0.0,1.0,-1.0,1.0);     // modo de projecao ortogonal
    glOrtho(0, 2 * largura, 2 * largura, 0, 1, -2);
    glMatrixMode(GL_MODELVIEW); // Select the projection matrix    
    glLoadIdentity();
      
}

bool colisaoInimigos()
{

  colisao = false;
  float distancia;
  for (std::list<Circulo *>::iterator it = inimigos.begin(); it != inimigos.end(); it++)
  {
    distancia = sqrt(pow((*it)->getx() - Aviao->getx(), 2) + pow((*it)->gety() - Aviao->gety(), 2));
    if (distancia < ((*it)->getRaio() + Aviao->getRaio()) && (*it)->getTipo() == 2)
    {
      colisao = true;
      break;
    }
  }
  return colisao;
}

void idle(int x)
{


    if(colisaoInimigos()) {
             startGame = false;  //Without keyStatus trick
             fimDecolagem = false;
             jaPassou = false;
    }

     if(sqrt(pow(Aviao->getx() - Pista->getx2(), 2) + pow(Aviao->gety() - Pista->gety2(), 2)) < 2*raioOriginal)
    jaPassou = true;
    
  float dist;
  if(curvando) {
     //2.098584
      float angulo;
          if(keyStatus[(int)('d')] ) {
                  //Aviao->sety(Aviao->gety() + curva);

            if(!dApertado) {
              dApertado = true;
              z = thetaOriginal/2.5; // d
            }

            if(startGame && fimDecolagem) { 

                thetaCanhao += 2*vel/6;
                angulo = z * 2 * M_PI / 1000;
                //theta = atan2(deltay2, deltax2)*180/M_PI;
                //printf("%.3f\n", theta);
                Aviao->setx(Aviao->getx() + (cos((vel*LAMBDA3*2)*angulo) * (vel*LAMBDA3)));
                Aviao->sety(Aviao->gety() + (sin((vel*LAMBDA3*2)*angulo) * (vel*LAMBDA3)));
                z++;
                if(z == 1000)
                z=0;
                //theta= 0;
            }
          }
          if(keyStatus[(int)('a')] ) {
                  //Aviao->sety(Aviao->gety() + curva);
              if(!dApertado) {
                dApertado = true;
              z = thetaOriginal/2; // a
              }
              if(startGame && fimDecolagem) { 

               //float angulo;
                thetaCanhao += 2*vel/6;
                angulo = z * 2 * M_PI / 1000;
                //theta = atan2(deltay2, deltax2)*180/M_PI;
                //printf("%.3f\n", theta);
                Aviao->setx(Aviao->getx() + (cos((vel*LAMBDA3*2)*angulo) * (vel*LAMBDA3)));
                Aviao->sety(Aviao->gety() + (sin((vel*LAMBDA3*2)*angulo) * (vel*LAMBDA3)));
                z--;
                if(z == -1000)
                z=0;
              //printf("angulo:%d\n", z);
                //theta= 0;
              //printf("angulo:%f\n", angulo);
            }
          }
          if(fimDecolagem && vel!= 0) {
      if(deltax == 0) {
      Pista->setx1(Pista->getx2());
      Pista->sety1(Aviao->getyAnt());
      Pista->setx2(Aviao->getx());
      Pista->sety2(Aviao->gety());
      deltax = abs(Pista->getx2() - Pista->getx1());
      deltay = abs(Pista->gety2() - Pista->gety1());
      deltax2 = (Pista->getx2() - Pista->getx1());
      deltay2 = (Pista->gety2() - Pista->gety1());
      theta = atan2(deltay2, deltax2)*180/M_PI;
      } else if(deltay == 0) {
      Pista->setx1(Aviao->getxAnt());
      Pista->sety1(Pista->gety2());
      Pista->setx2(Aviao->getx());
      Pista->sety2(Aviao->gety());
      deltax = abs(Pista->getx2() - Pista->getx1());
      deltay = abs(Pista->gety2() - Pista->gety1());
    deltax2 = (Pista->getx2() - Pista->getx1());
      deltay2 = (Pista->gety2() - Pista->gety1());
      theta = atan2(deltay2, deltax2)*180/M_PI;
      } else {
      Pista->setx1(Aviao->getxAnt());
      Pista->sety1(Aviao->getyAnt());
      Pista->setx2(Aviao->getx());
      Pista->sety2(Aviao->gety());
      deltax = abs(Pista->getx2() - Pista->getx1());
      deltay = abs(Pista->gety2() - Pista->gety1());
      deltax2 = (Pista->getx2() - Pista->getx1());
      deltay2 = (Pista->gety2() - Pista->gety1());
      theta = atan2(deltay2, deltax2)*180/M_PI;
    }
  }

  if(deltax > 0 && deltay == 0) { // Pista reta horizontalmente

            alberto = sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - Aviao->gety(), 2));
            if(alberto > Arena->getRaio() ) {
              
              float x, y;
              jadir = alberto - Arena->getRaio();
              //cout << "arena: " << Arena->getRaio() << " ";
              //cout << "alberto" << alberto << " ";
              //cout << "jadir" << jadir << " ";

            if(Pista->getx2() - Pista->getx1() > 0)
                x = Aviao->getx() - jadir;
            if(Pista->getx2() - Pista->getx1() < 0)
                x = Aviao->getx() + jadir;

            while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - Aviao->gety(), 2)) > Arena->getRaio()) {

               if(Pista->getx2() - Pista->getx1() > 0)
                x = x - 0.01;
              if(Pista->getx2() - Pista->getx1() < 0)
                x = x + 0.01;

            }
 
              
              while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - Aviao->gety(), 2)) <= Arena->getRaio()) {

              if(Pista->getx2() - Pista->getx1() > 0)
                x = x - 0.1;
              if(Pista->getx2() - Pista->getx1() < 0)
                x = x + 0.1;
              }

              Aviao->setx(x);
              //Aviao->sety(y);

      }
  }
  if(deltay > 0 && deltax == 0) { // Pista reta verticalmente
          //Aviao->setx(Aviao->getx() + vel);
          //Aviao->sety(Aviao->gety() - vel);

            alberto = sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - Aviao->gety(), 2));
            if(alberto > Arena->getRaio() ) {
              
              float x, y;
              jadir = alberto - Arena->getRaio();
              //cout << "arena: " << Arena->getRaio() << " ";
              //cout << "alberto" << alberto << " ";
              //cout << "jadir" << jadir << " ";

            if(Pista->gety2() - Pista->gety1() > 0)
              y = Aviao->gety() - jadir;
            if(Pista->gety2() - Pista->gety1() < 0)
              y = Aviao->gety() + jadir;

            while(sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - y, 2)) > Arena->getRaio()) {

              if(Pista->gety2() - Pista->gety1() > 0)
                y = y - 0.01;
              if(Pista->gety2() - Pista->gety1() < 0)
                y = y + 0.01;

            }

              
              while(sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - y, 2)) <= Arena->getRaio()) {

              if(Pista->gety2() - Pista->gety1() > 0)
                y = y - 0.1;
              if(Pista->gety2() - Pista->gety1() < 0)
                y = y + 0.1;
                
              }

              //Aviao->setx(x);
              Aviao->sety(y);

            }
    }
    if(deltax > 0 && deltay > 0) { // Pista inclinada

          if(deltax > deltay) {
            
            alberto = sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - Aviao->gety(), 2));
            if(alberto > Arena->getRaio() ) {
              
              float x, y;
              jadir = alberto - Arena->getRaio();
              //cout << "arena: " << Arena->getRaio() << " ";
              //cout << "alberto" << alberto << " ";
              //cout << "jadir" << jadir << " ";
              //                  printf("jadir: %f alberto: %f\n", jadir, alberto);            

            if(Pista->getx2() - Pista->getx1() > 0)
                x = Aviao->getx() - jadir;
            if(Pista->getx2() - Pista->getx1() < 0)
                x = Aviao->getx() + jadir;
            if(Pista->gety2() - Pista->gety1() > 0)
              y = Aviao->gety() - jadir/(deltax/deltay);
            if(Pista->gety2() - Pista->gety1() < 0)
              y = Aviao->gety() + jadir/(deltax/deltay);

            while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - y, 2)) > Arena->getRaio()) {

              if(Pista->getx2() - Pista->getx1() > 0)
                x = x - 0.01;
              if(Pista->getx2() - Pista->getx1() < 0)
                x = x + 0.01;
              if(Pista->gety2() - Pista->gety1() > 0)
                y = y - 0.01/(deltax/deltay);
              if(Pista->gety2() - Pista->gety1() < 0)
                y = y + 0.01/(deltax/deltay);

                

            }
              
            while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - y, 2)) <= Arena->getRaio()) {

              if(Pista->getx2() - Pista->getx1() > 0)
                x = x - 0.1;
              if(Pista->getx2() - Pista->getx1() < 0)
                x = x + 0.1;
              if(Pista->gety2() - Pista->gety1() > 0)
                y = y - 0.1/(deltax/deltay);
              if(Pista->gety2() - Pista->gety1() < 0)
                y = y + 0.1/(deltax/deltay);

               //printf("2\n");
                
                //printf("PASSOU AQUI\n");
            }

              Aviao->setx(x);
              Aviao->sety(y);

            }


          }
          if(deltay > deltax) {
            
            alberto = sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - Aviao->gety(), 2));
            if(alberto > Arena->getRaio() ) {
              
              float x, y;
              jadir = alberto - Arena->getRaio();
              //cout << "arena: " << Arena->getRaio() << " ";
              //cout << "alberto" << alberto << " ";
              //cout << "jadir" << jadir << " ";

            if(Pista->getx2() - Pista->getx1() > 0)
                x = Aviao->getx() - jadir/(deltay/deltax);
            if(Pista->getx2() - Pista->getx1() < 0)
                x = Aviao->getx() + jadir/(deltay/deltax);
            if(Pista->gety2() - Pista->gety1() > 0)
              y = Aviao->gety() - jadir;
            if(Pista->gety2() - Pista->gety1() < 0)
              y = Aviao->gety() + jadir;


            while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - y, 2)) > Arena->getRaio()) {

                if(Pista->getx2() - Pista->getx1() > 0)
                  x = x - 0.01/(deltay/deltax);
                if(Pista->getx2() - Pista->getx1() < 0)
                  x = x + 0.01/(deltay/deltax);
                if(Pista->gety2() - Pista->gety1() > 0)
                  y = y - 0.01;
                if(Pista->gety2() - Pista->gety1() < 0)
                  y = y + 0.01;
            }

              while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - y, 2)) <= Arena->getRaio()) {

              if(Pista->getx2() - Pista->getx1() > 0)
                x = x - 0.1/(deltay/deltax);
              if(Pista->getx2() - Pista->getx1() < 0)
                x = x + 0.1/(deltay/deltax);
              if(Pista->gety2() - Pista->gety1() > 0)
                y = y - 0.1;
              if(Pista->gety2() - Pista->gety1() < 0)
                y = y + 0.1;
                
              }

              Aviao->setx(x);
              Aviao->sety(y);

            }

            //cout << "esta aqui\n"
          }
          if(deltay == deltax) {

            alberto = sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - Aviao->gety(), 2));
            if(alberto > Arena->getRaio() ) {
              
              float x, y;
              jadir = alberto - Arena->getRaio();
              //cout << "arena: " << Arena->getRaio() << " ";
              //cout << "alberto" << alberto << " ";
              //cout << "jadir" << jadir << " ";

            if(Pista->getx2() - Pista->getx1() > 0)
                x = Aviao->getx() - jadir;
            if(Pista->getx2() - Pista->getx1() < 0)
                x = Aviao->getx() + jadir;
            if(Pista->gety2() - Pista->gety1() > 0)
              y = Aviao->gety() - jadir;
            if(Pista->gety2() - Pista->gety1() < 0)
              y = Aviao->gety() + jadir;

             while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - y, 2)) > Arena->getRaio()) {

                if(Pista->getx2() - Pista->getx1() > 0)
                   x = x - 0.01;
                if(Pista->getx2() - Pista->getx1() < 0)
                   x = x + 0.01;
                if(Pista->gety2() - Pista->gety1() > 0)
                  y = y - 0.01;
                if(Pista->gety2() - Pista->gety1() < 0)
                  y = y + 0.01;
            }

              while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - y, 2)) <= Arena->getRaio()) {

              if(Pista->getx2() - Pista->getx1() > 0)
                x = x - 0.1;
              if(Pista->getx2() - Pista->getx1() < 0)
                x = x + 0.1;
              if(Pista->gety2() - Pista->gety1() > 0)
                y = y - 0.1;
              if(Pista->gety2() - Pista->gety1() < 0)
                y = y + 0.1;
                
              }

              Aviao->setx(x);
              Aviao->sety(y);

            }

          }
          
    }

      
  }  else {
  if (startGame)
  {
    if(dist = sqrt(pow(Aviao->getx() - Pista->getx2(), 2) + pow(Aviao->gety() - Pista->gety2(), 2)) <= tamPista/2 + raioOriginal) {

      if(Aviao->getRaio() < 2*raioOriginal) {

        if(tamPista > 200) {   
          Aviao->setRaio(Aviao->getRaio() + 0.15 * (raioOriginal/10)); 
          scale = Aviao->getRaio()/LAMBDA2;
        }
        if(tamPista <= 200 && tamPista > 100) {
          Aviao->setRaio(Aviao->getRaio() + 0.13* (raioOriginal/10) );
          scale = Aviao->getRaio()/LAMBDA2;
        }
       if(tamPista <= 100 && tamPista > 50) {
          Aviao->setRaio(Aviao->getRaio() + 0.1 * (raioOriginal/10) );
          scale = Aviao->getRaio()/LAMBDA2;
        }
        if(tamPista <= 50) {
          Aviao->setRaio(Aviao->getRaio() + 0.072 * (raioOriginal/10));
          scale = Aviao->getRaio()/LAMBDA2;
        }
      }
    }

    if(deltax > 0 && deltay == 0) { // Pista reta horizontalmente

            alberto = sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - Aviao->gety(), 2));
            if(alberto > Arena->getRaio() ) {
              
              float x, y;
              jadir = alberto - Arena->getRaio();
              //cout << "arena: " << Arena->getRaio() << " ";
              //cout << "alberto" << alberto << " ";
              //cout << "jadir" << jadir << " ";

            if(Pista->getx2() - Pista->getx1() > 0)
                x = Aviao->getx() - jadir;
            if(Pista->getx2() - Pista->getx1() < 0)
                x = Aviao->getx() + jadir;

            while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - Aviao->gety(), 2)) > Arena->getRaio()) {

               if(Pista->getx2() - Pista->getx1() > 0)
                x = x - 0.01;
              if(Pista->getx2() - Pista->getx1() < 0)
                x = x + 0.01;

            }
 
              
              while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - Aviao->gety(), 2)) <= Arena->getRaio()) {

              if(Pista->getx2() - Pista->getx1() > 0)
                x = x - 0.1;
              if(Pista->getx2() - Pista->getx1() < 0)
                x = x + 0.1;
              }

              Aviao->setx(x);
              //Aviao->sety(y);

            }

          if(Pista->getx2() - Pista->getx1() > 0)
            Aviao->setx(Aviao->getx() + vel);
          if(Pista->getx2() - Pista->getx1() < 0)
            Aviao->setx(Aviao->getx() - vel);
          //Aviao->sety(Aviao->gety() - vel/2);
    }

    if(deltay > 0 && deltax == 0) { // Pista reta verticalmente
          //Aviao->setx(Aviao->getx() + vel);
          //Aviao->sety(Aviao->gety() - vel);

            alberto = sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - Aviao->gety(), 2));
            if(alberto > Arena->getRaio() ) {
              
              float x, y;
              jadir = alberto - Arena->getRaio();
              //cout << "arena: " << Arena->getRaio() << " ";
              //cout << "alberto" << alberto << " ";
              //cout << "jadir" << jadir << " ";

            if(Pista->gety2() - Pista->gety1() > 0)
              y = Aviao->gety() - jadir;
            if(Pista->gety2() - Pista->gety1() < 0)
              y = Aviao->gety() + jadir;

            while(sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - y, 2)) > Arena->getRaio()) {

              if(Pista->gety2() - Pista->gety1() > 0)
                y = y - 0.01;
              if(Pista->gety2() - Pista->gety1() < 0)
                y = y + 0.01;

            }

              
              while(sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - y, 2)) <= Arena->getRaio()) {

              if(Pista->gety2() - Pista->gety1() > 0)
                y = y - 0.1;
              if(Pista->gety2() - Pista->gety1() < 0)
                y = y + 0.1;
                
              }

              //Aviao->setx(x);
              Aviao->sety(y);

            }

          if(Pista->gety2() - Pista->gety1() > 0)
            Aviao->sety(Aviao->gety() + vel);
          if(Pista->gety2() - Pista->gety1() < 0)
            Aviao->sety(Aviao->gety() - vel);                 
    }

    if(deltax > 0 && deltay > 0) { // Pista inclinada

          if(deltax > deltay) {
            
            alberto = sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - Aviao->gety(), 2));
            if(alberto > Arena->getRaio() ) {
              
              float x, y;
              jadir = alberto - Arena->getRaio();
              //cout << "arena: " << Arena->getRaio() << " ";
              //cout << "alberto" << alberto << " ";
              //cout << "jadir" << jadir << " ";
              //                  printf("jadir: %f alberto: %f\n", jadir, alberto);            

            if(Pista->getx2() - Pista->getx1() > 0)
                x = Aviao->getx() - jadir;
            if(Pista->getx2() - Pista->getx1() < 0)
                x = Aviao->getx() + jadir;
            if(Pista->gety2() - Pista->gety1() > 0)
              y = Aviao->gety() - jadir/(deltax/deltay);
            if(Pista->gety2() - Pista->gety1() < 0)
              y = Aviao->gety() + jadir/(deltax/deltay);

            while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - y, 2)) > Arena->getRaio()) {

              if(Pista->getx2() - Pista->getx1() > 0)
                x = x - 0.01;
              if(Pista->getx2() - Pista->getx1() < 0)
                x = x + 0.01;
              if(Pista->gety2() - Pista->gety1() > 0)
                y = y - 0.01/(deltax/deltay);
              if(Pista->gety2() - Pista->gety1() < 0)
                y = y + 0.01/(deltax/deltay);

                

            }
              
            while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - y, 2)) <= Arena->getRaio()) {

              if(Pista->getx2() - Pista->getx1() > 0)
                x = x - 0.1;
              if(Pista->getx2() - Pista->getx1() < 0)
                x = x + 0.1;
              if(Pista->gety2() - Pista->gety1() > 0)
                y = y - 0.1/(deltax/deltay);
              if(Pista->gety2() - Pista->gety1() < 0)
                y = y + 0.1/(deltax/deltay);

               //printf("2\n");
                
                //printf("PASSOU AQUI\n");
            }
             //printf("2\n");

              Aviao->setx(x);
              Aviao->sety(y);

            }

            // << "esta aqui\n";

            if(Pista->getx2() - Pista->getx1() > 0)
              Aviao->setx(Aviao->getx() + vel);
            if(Pista->getx2() - Pista->getx1() < 0)
              Aviao->setx(Aviao->getx() - vel);
            if(Pista->gety2() - Pista->gety1() > 0) 
               Aviao->sety(Aviao->gety() + vel/(deltax/deltay));
            if(Pista->gety2() - Pista->gety1() < 0) 
              Aviao->sety(Aviao->gety() - vel/(deltax/deltay));


          }
          if(deltay > deltax) {
            
            alberto = sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - Aviao->gety(), 2));
            if(alberto > Arena->getRaio() ) {
              
              float x, y;
              jadir = alberto - Arena->getRaio();
              //cout << "arena: " << Arena->getRaio() << " ";
              //cout << "alberto" << alberto << " ";
              //cout << "jadir" << jadir << " ";

            if(Pista->getx2() - Pista->getx1() > 0)
                x = Aviao->getx() - jadir/(deltay/deltax);
            if(Pista->getx2() - Pista->getx1() < 0)
                x = Aviao->getx() + jadir/(deltay/deltax);
            if(Pista->gety2() - Pista->gety1() > 0)
              y = Aviao->gety() - jadir;
            if(Pista->gety2() - Pista->gety1() < 0)
              y = Aviao->gety() + jadir;


            while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - y, 2)) > Arena->getRaio()) {

                if(Pista->getx2() - Pista->getx1() > 0)
                  x = x - 0.01/(deltay/deltax);
                if(Pista->getx2() - Pista->getx1() < 0)
                  x = x + 0.01/(deltay/deltax);
                if(Pista->gety2() - Pista->gety1() > 0)
                  y = y - 0.01;
                if(Pista->gety2() - Pista->gety1() < 0)
                  y = y + 0.01;
            }

              while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - y, 2)) <= Arena->getRaio()) {

              if(Pista->getx2() - Pista->getx1() > 0)
                x = x - 0.1/(deltay/deltax);
              if(Pista->getx2() - Pista->getx1() < 0)
                x = x + 0.1/(deltay/deltax);
              if(Pista->gety2() - Pista->gety1() > 0)
                y = y - 0.1;
              if(Pista->gety2() - Pista->gety1() < 0)
                y = y + 0.1;
                
              }

              Aviao->setx(x);
              Aviao->sety(y);

            }

            //cout << "esta aqui\n";

            if(Pista->gety2() - Pista->gety1() > 0)
              Aviao->sety(Aviao->gety() + vel);
            if(Pista->gety2() - Pista->gety1() < 0)
              Aviao->sety(Aviao->gety() - vel);
            if(Pista->getx2() - Pista->getx1() > 0) 
               Aviao->setx(Aviao->getx() + vel/(deltay/deltax));
            if(Pista->getx2() - Pista->getx1() < 0) 
              Aviao->setx(Aviao->getx() - vel/(deltay/deltax));
            

          }
          if(deltay == deltax) {

            alberto = sqrt(pow(Arena->getx() - Aviao->getx(), 2) + pow(Arena->gety() - Aviao->gety(), 2));
            if(alberto > Arena->getRaio() ) {
              
              float x, y;
              jadir = alberto - Arena->getRaio();
              //cout << "arena: " << Arena->getRaio() << " ";
              //cout << "alberto" << alberto << " ";
              //cout << "jadir" << jadir << " ";

            if(Pista->getx2() - Pista->getx1() > 0)
                x = Aviao->getx() - jadir;
            if(Pista->getx2() - Pista->getx1() < 0)
                x = Aviao->getx() + jadir;
            if(Pista->gety2() - Pista->gety1() > 0)
              y = Aviao->gety() - jadir;
            if(Pista->gety2() - Pista->gety1() < 0)
              y = Aviao->gety() + jadir;

             while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - y, 2)) > Arena->getRaio()) {

                if(Pista->getx2() - Pista->getx1() > 0)
                   x = x - 0.01;
                if(Pista->getx2() - Pista->getx1() < 0)
                   x = x + 0.01;
                if(Pista->gety2() - Pista->gety1() > 0)
                  y = y - 0.01;
                if(Pista->gety2() - Pista->gety1() < 0)
                  y = y + 0.01;
            }

              while(sqrt(pow(Arena->getx() - x, 2) + pow(Arena->gety() - y, 2)) <= Arena->getRaio()) {

              if(Pista->getx2() - Pista->getx1() > 0)
                x = x - 0.1;
              if(Pista->getx2() - Pista->getx1() < 0)
                x = x + 0.1;
              if(Pista->gety2() - Pista->gety1() > 0)
                y = y - 0.1;
              if(Pista->gety2() - Pista->gety1() < 0)
                y = y + 0.1;
                
              }

              Aviao->setx(x);
              Aviao->sety(y);

            }

            if(Pista->getx2() - Pista->getx1() > 0)
              Aviao->setx(Aviao->getx() + vel);
            if(Pista->getx2() - Pista->getx1() < 0)
              Aviao->setx(Aviao->getx() - vel);
            if(Pista->gety2() - Pista->gety1() > 0)
              Aviao->sety(Aviao->gety() + vel);
            if(Pista->gety2() - Pista->gety1() < 0)
              Aviao->sety(Aviao->gety() - vel);

          }
          
    }

    if(!fimDecolagem) {
    vel = vel + aceleracaoIdeal;
    thetaCanhao += 2*vel/6;
    } else {
      thetaCanhao += 2*vel/6;
    }

     
     if (jaPassou && sqrt(pow(Pista->getx2() - Aviao->getx(), 2) + pow(Pista->gety2() - Aviao->gety(), 2)) >= 2*raioOriginal) {
      //startGame = false;
      //cout<< Aviao->getRaio();
      Aviao->setRaio(2*raioOriginal);
      scale = Aviao->getRaio()/LAMBDA2;
      vel = vel * velocidade;
      fimDecolagem = true;
      //printf("%f\n", vel);
      //cout << tamPista;
    }
    
  }
  
  } // chave do curvando


    if(fimDecolagem && vel != 0) {
      if(deltax == 0) {
      Pista->setx1(Pista->getx2());
      Pista->sety1(Aviao->getyAnt());
      Pista->setx2(Aviao->getx());
      Pista->sety2(Aviao->gety());
      deltax = abs(Pista->getx2() - Pista->getx1());
      deltay = abs(Pista->gety2() - Pista->gety1());
      deltax2 = (Pista->getx2() - Pista->getx1());
      deltay2 = (Pista->gety2() - Pista->gety1());
      theta = atan2(deltay2, deltax2)*180/M_PI;
      } else if(deltay == 0) {
      Pista->setx1(Aviao->getxAnt());
      Pista->sety1(Pista->gety2());
      Pista->setx2(Aviao->getx());
      Pista->sety2(Aviao->gety());
      deltax = abs(Pista->getx2() - Pista->getx1());
      deltay = abs(Pista->gety2() - Pista->gety1());
    deltax2 = (Pista->getx2() - Pista->getx1());
      deltay2 = (Pista->gety2() - Pista->gety1());
      theta = atan2(deltay2, deltax2)*180/M_PI;
      } else {
      Pista->setx1(Aviao->getxAnt());
      Pista->sety1(Aviao->getyAnt());
      Pista->setx2(Aviao->getx());
      Pista->sety2(Aviao->gety());
      deltax = abs(Pista->getx2() - Pista->getx1());
      deltay = abs(Pista->gety2() - Pista->gety1());
      deltax2 = (Pista->getx2() - Pista->getx1());
      deltay2 = (Pista->gety2() - Pista->gety1());
      theta = atan2(deltay2, deltax2)*180/M_PI;
    }
}

    
    glutPostRedisplay();
    glutTimerFunc(1000 / FPS, idle, 0);
}
 
int main(int argc, char *argv[])
{
    // Initialize openGL with Double buffer and RGB color without transparency.
    // Its interesting to try GLUT_SINGLE instead of GLUT_DOUBLE.
    
    if(argc != 2) {
  printf("[USO]: ./trabalhocg <argumento1>\n");
  exit(0);
  }

  // leitura do XML
  //char *dir;
  //dir = get_current_dir_name();
  //char *argumento;
  //strcpy(argumento, dir);
  //std::string filename = argv[1];
  //strcat(dir, argv[1]);
  //strcat(dir, "config.xml");
  //cout << argumento;
  //cout << argv[1];

  char cwd[512];
  strcat(cwd, argv[1]);
  strcat(cwd, "config.xml");
  //cout << cwd;

  TiXmlDocument doc(cwd);

  if(!doc.LoadFile()) {
    cout << "Nao foi possivel localizar o arquivo config.xml\n";
    exit(0);
  }

  TiXmlHandle docHandle(&doc);
  TiXmlElement *leitura = docHandle.FirstChild("aplicacao").FirstChild("arquivoDaArena").FirstChild("nome").ToElement();

  nome = leitura->GetText();

  leitura = docHandle.FirstChild("aplicacao").FirstChild("arquivoDaArena").FirstChild("tipo").ToElement();

  tipo = leitura->GetText();

  leitura = docHandle.FirstChild("aplicacao").FirstChild("arquivoDaArena").FirstChild("caminho").ToElement();

  caminho = leitura->GetText();

  leitura = docHandle.FirstChild("aplicacao").FirstChild("jogador").ToElement();

  velocidade = atof(leitura->Attribute("vel"));
  velTiro = atof(leitura->Attribute("velTiro"));

  // fim da leitura do primeiro XML
  char *nomeSVG = strdup(nome);
  char *tipoSVG = strdup(tipo);
  strcat(nomeSVG, ".");
  strcat(nomeSVG, tipoSVG);
  strcat((char*)caminho, nomeSVG);
  //cout << caminho;
  TiXmlDocument doc2(caminho);
   if(!doc2.LoadFile()) {
    cout << "Nao foi possivel localizar o arquivo arena.svg\n";
    exit(0);
  }
  TiXmlHandle docHandle2(&doc2);

  TiXmlElement *leitura2 = docHandle2.FirstChild("svg").Child("circle", 0).ToElement();

  float wraio, wx, wy, wg, wb, wtipo;
  const char* fill;
  while(leitura2) {

    fill = leitura2->Attribute("fill");

    if (strcmp(fill, "blue") == 0) {
    	largura = atof(leitura2->Attribute("r"));
  		altura = atof(leitura2->Attribute("r"));
  		wx = atof(leitura2->Attribute("cx"));
      wy = atof(leitura2->Attribute("cy"));
      //MUDAR SINAL AQUI!!9
  		deslocamentox = abs(wx - largura);
      deslocamentoy = abs(wy - largura);

  		//printf("%f\n", deslocamento);
		Arena = new Circulo(largura, largura, altura, 0, 0, 254, 0);
    }
    leitura2 = leitura2->NextSiblingElement("circle");
  }

    //cout << deslocamento << "\n";
  // garantir o deslocamento

  leitura2 = docHandle2.FirstChild("svg").Child("circle", 0).ToElement();

  while(leitura2) {

    fill = leitura2->Attribute("fill");

    if (strcmp(fill, "green") == 0) {
    	wraio = atof(leitura2->Attribute("r"));
  		wx = atof(leitura2->Attribute("cx"));
  		wy = atof(leitura2->Attribute("cy"));
      raioOriginal = wraio;
      scale = raioOriginal/LAMBDA2;
  		//deslocamento = wx - largura;
  		//printf("%f\n", deslocamento);
		Aviao = new Circulo(wraio, wx-deslocamentox, wy-deslocamentoy, 0, 0.8, 0, 1);
    }

    if (strcmp(fill, "red") == 0) {
    	wraio = atof(leitura2->Attribute("r"));
  		wx = atof(leitura2->Attribute("cx"));
  		wy = atof(leitura2->Attribute("cy"));
  		//deslocamento = wx - largura;
  		//printf("%f\n", deslocamento);
      raioVoador = wraio;
		circ = new Circulo(wraio, wx-deslocamentox, wy-deslocamentoy, 1, 0, 0, 2);
		inimigos.push_front(circ);
    }

    if (strcmp(fill, "orange") == 0) {
    	wraio = atof(leitura2->Attribute("r"));
  		wx = atof(leitura2->Attribute("cx"));
  		wy = atof(leitura2->Attribute("cy"));
  		//deslocamento = wx - largura;
  		//printf("%f\n", deslocamento);
		circ = new Circulo(wraio, wx-deslocamentox, wy-deslocamentoy, 1, 0.65, 0, 3);
		inimigos.push_front(circ);
    }

    leitura2 = leitura2->NextSiblingElement("circle");
  }

  // PARA FAZER LEITURA DO RETANGULO

  float wx1, wx2, wy1, wy2;

  leitura2 = docHandle2.FirstChild("svg").Child("line", 0).ToElement();

   wx1 = atof(leitura2->Attribute("x1"));
   wy1 = atof(leitura2->Attribute("y1"));
   wx2 = atof(leitura2->Attribute("x2"));
   wy2 = atof(leitura2->Attribute("y2"));


   // para tratar o angulo
   deltax2 = (wx2 - wx1);
   deltay2 = (wy2 - wy1);

   deltaxOriginal = deltax2;
   deltayOriginal = deltay2;

   deltax = abs(wx2 - wx1);
   deltay = abs(wy2 - wy1);

   tangente = atan2(deltay2, deltax2);
   thetaOriginal = tangente*180/M_PI;
   theta = thetaOriginal;
   //printf("%f\n", tangente);

   Pista = new Retangulo(wx1-deslocamentox,wx2-deslocamentox,wy1-deslocamentoy, wy2-deslocamentoy);

   Pista2 = new Retangulo(wx1-deslocamentox,wx2-deslocamentox,wy1-deslocamentoy, wy2-deslocamentoy);

  //cout << Pista->getx2();

   tamPista = sqrt(pow(wx1 - wx2, 2) + pow(wy1 - wy2, 2));
   distLimite = ( Arena->getRaio() - Aviao->getRaio() ) ;

   velocidadeIdeal = tamPista/LAMBDA;
   aceleracaoIdeal = ( pow(velocidadeIdeal, 2) / (2*tamPista) );

   vel = aceleracaoIdeal;
   
   robo = new Robo(Aviao->getRaio(), Aviao->getx(), Aviao->gety(), Aviao->getR(), Aviao->getG(), Aviao->getB());

   xOriginal = Aviao->getx();
   yOriginal = Aviao->gety();
   pistax1Original = Pista->getx1();
   pistax2Original = Pista->getx2();
   pistay1Original= Pista->gety1();
   pistay2Original = Pista->gety2();
   
   glutInit(&argc, argv);                       // inicializa o glut
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB); // especifica o uso de cores e buffers
   glutInitWindowSize(2 * largura, 2 * altura); // especifica as dimensoes da janela
   glutInitWindowPosition(100, 100);            // especifica aonde a janela aparece na tela
   glutCreateWindow("Trabalho 3 - CG");                    // cria a janela
   init();
  
   glutSetKeyRepeat(GLUT_KEY_REPEAT_OFF);

   glutDisplayFunc(display);

   glutMouseFunc(ClicarMouse); 
   glutPassiveMotionFunc(MouseAndandoNaoPressionado);

   glutKeyboardFunc(keyPress);
   glutKeyboardUpFunc(keyup);

  

   glutTimerFunc(1000 / FPS, idle, 0); // funcao que sera redesenhada pelo GLUT
   glutMainLoop();
  
    //glutDisplayFunc(renderScene);
    //glutKeyboardFunc(keyPress);
    //glutIdleFunc(idle);
    //glutKeyboardUpFunc(keyup);
 
 
    return 0;
}
