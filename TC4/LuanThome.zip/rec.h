class Retangulo
{
  private:
  float x1, x2,y1, y2;
  public:
    Retangulo(float x1, float x2, float y1, float y2);
    float getx1();
    void setx1(float b);
    float gety1();
    void sety1(float b);
    float getx2();
    void setx2(float b);
    float gety2();
    void sety2(float b);
};

